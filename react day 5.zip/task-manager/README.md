# Task Manager (React + Redux + Thunk + Router + Lazy Loading)

This project is a complete implementation of the **Day 5 CC 4: React Coding Challenge** described in the PDF:

- Authentication (Login & Protected Routes)
- Task Dashboard (List, Add, Delete Tasks)
- Lazy Loading & Code Splitting
- Redux Middleware & State Management (redux-thunk)
- LocalStorage persistence for auth

## Quick Start

```bash
# 1) Extract the ZIP
unzip task-manager.zip && cd task-manager

# 2) Install deps
npm install

# 3) Start dev server
npm run dev
```

Open the printed local URL (usually http://localhost:5173).

## Login

Use any username and the password **admin** (for demo). Auth state persists in `localStorage`.

## Tech

- React 18
- React Router v6
- Redux + react-redux
- redux-thunk
- Vite (build tool)

## Structure

```
/task-manager
├── index.html
├── vite.config.js
├── package.json
└── src
    ├── App.jsx
    ├── index.jsx
    ├── styles.css
    ├── /components
    │   ├── Navbar.jsx
    │   ├── ProtectedRoute.jsx
    │   ├── TaskItem.jsx
    │   └── TaskList.jsx
    ├── /pages
    │   ├── Dashboard.jsx
    │   ├── Home.jsx
    │   ├── Login.jsx
    │   └── Profile.jsx
    └── /redux
        ├── actions.js
        ├── reducers.js
        └── store.js
```

## Notes

- Pages **Dashboard** and **Profile** are code-split via `React.lazy` and `Suspense`.
- Redux DevTools extension is supported if installed in your browser.
- You can swap the simulated login for a real API later.
