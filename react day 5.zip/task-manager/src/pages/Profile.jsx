import React from 'react'
import { useSelector } from 'react-redux'

export default function Profile() {
  const user = useSelector(s => s.auth.user)
  return (
    <div className="card">
      <h2>Profile</h2>
      <p><strong>Username:</strong> {user?.username}</p>
      <p className="badge">Authenticated</p>
    </div>
  )
}
