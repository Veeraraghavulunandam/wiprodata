import React, { useState } from 'react'
import { useDispatch, useSelector } from 'react-redux'
import { login } from '../redux/actions'
import { useLocation, useNavigate } from 'react-router-dom'

export default function Login() {
  const [username, setUsername] = useState('')
  const [password, setPassword] = useState('')
  const dispatch = useDispatch()
  const navigate = useNavigate()
  const location = useLocation()
  const loading = useSelector(s => s.auth.loading)
  const error = useSelector(s => s.auth.error)

  const from = location.state?.from?.pathname || '/dashboard'

  const onSubmit = (e) => {
    e.preventDefault()
    dispatch(login(username, password, () => navigate(from, { replace: true })))
  }

  return (
    <div className="grid" style={{ maxWidth: 520, margin: '0 auto' }}>
      <div className="card">
        <h2>Login</h2>
        <form className="grid" onSubmit={onSubmit}>
          <label className="col">
            <span>Username</span>
            <input className="input" value={username} onChange={e => setUsername(e.target.value)} placeholder="e.g. alex" />
          </label>
          <label className="col">
            <span>Password</span>
            <input className="input" type="password" value={password} onChange={e => setPassword(e.target.value)} placeholder="••••••••" />
          </label>
          {error && <div className="card" style={{ borderColor: 'crimson' }}>{error}</div>}
          <button className="btn primary" disabled={loading}>{loading ? 'Signing in…' : 'Login'}</button>
        </form>
      </div>
      <div className="card">
        <p>Try any username and password <code>admin</code> to pass.</p>
      </div>
    </div>
  )
}
