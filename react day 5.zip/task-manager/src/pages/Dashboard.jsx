import React, { useState } from 'react'
import { useDispatch, useSelector } from 'react-redux'
import { addTask, deleteTask } from '../redux/actions'
import TaskList from '../components/TaskList'

export default function Dashboard() {
  const [title, setTitle] = useState('')
  const tasks = useSelector(s => s.tasks.items)
  const dispatch = useDispatch()

  const add = (e) => {
    e.preventDefault()
    const trimmed = title.trim()
    if (!trimmed) return
    dispatch(addTask(trimmed))
    setTitle('')
  }

  return (
    <div className="grid" style={{ gap: 16 }}>
      <div className="card">
        <h2>Task Dashboard</h2>
        <form className="row" onSubmit={add}>
          <input className="input" value={title} onChange={e => setTitle(e.target.value)} placeholder="What needs to be done?" />
          <button className="btn success" type="submit">Add Task</button>
        </form>
      </div>
      <TaskList tasks={tasks} onDelete={(id) => dispatch(deleteTask(id))} />
    </div>
  )
}
