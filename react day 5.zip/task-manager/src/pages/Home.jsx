import React from 'react'
import { Link } from 'react-router-dom'

export default function Home() {
  return (
    <div className="grid" style={{ gap: 24 }}>
      <div className="card">
        <h1>Welcome 👋</h1>
        <p>
          This is a <strong>Task Management</strong> app showcasing:
          Authentication, Protected Routes, Redux + Thunk, and Lazy Loaded pages.
        </p>
        <div className="row">
          <Link className="btn primary" to="/login">Login</Link>
          <Link className="btn" to="/dashboard">Go to Dashboard</Link>
        </div>
      </div>
      <div className="grid grid-3">
        <div className="card">
          <h3>🔐 Authentication</h3>
          <p>Login state persists in localStorage and guards protected routes.</p>
        </div>
        <div className="card">
          <h3>🧭 Routing + Lazy Loading</h3>
          <p>React Router v6 with code-split pages using <code>React.lazy</code> & <code>Suspense</code>.</p>
        </div>
        <div className="card">
          <h3>🧠 Redux + Thunk</h3>
          <p>Centralized task state with async actions available via redux-thunk.</p>
        </div>
      </div>
    </div>
  )
}
