import React from 'react'

export default function TaskItem({ task, onDelete }) {
  return (
    <div className="task">
      <div className="task-title">{task.title}</div>
      <div className="row">
        <span className="badge">#{task.id}</span>
        <button className="btn" onClick={() => onDelete(task.id)}>Delete</button>
      </div>
    </div>
  )
}
