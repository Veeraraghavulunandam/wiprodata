import React from 'react'
import TaskItem from './TaskItem'

export default function TaskList({ tasks, onDelete }) {
  if (!tasks.length) return <div className="card">No tasks yet. Add one!</div>
  return (
    <div className="grid">
      {tasks.map(t => (
        <TaskItem key={t.id} task={t} onDelete={onDelete} />
      ))}
    </div>
  )
}
