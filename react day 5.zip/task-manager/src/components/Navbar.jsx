import React from 'react'
import { NavLink, useNavigate } from 'react-router-dom'
import { useDispatch, useSelector } from 'react-redux'
import { logout } from '../redux/actions'

export default function Navbar() {
  const navigate = useNavigate()
  const dispatch = useDispatch()
  const isAuth = useSelector(state => state.auth.isAuthenticated)
  const user = useSelector(state => state.auth.user)

  const handleLogout = () => {
    dispatch(logout())
    navigate('/login')
  }

  return (
    <nav className="navbar">
      <div className="nav-brand">🗂️ Task Manager</div>
      <div className="nav-links">
        <NavLink to="/" className={({isActive}) => 'nav-link' + (isActive ? ' active' : '')}>Home</NavLink>
        <NavLink to="/dashboard" className={({isActive}) => 'nav-link' + (isActive ? ' active' : '')}>Dashboard</NavLink>
        <NavLink to="/profile" className={({isActive}) => 'nav-link' + (isActive ? ' active' : '')}>Profile</NavLink>
        {!isAuth ? (
          <NavLink to="/login" className={({isActive}) => 'nav-link' + (isActive ? ' active' : '')}>Login</NavLink>
        ) : (
          <button className="btn" onClick={handleLogout}>Logout {user?.username ? `(${user.username})` : ''}</button>
        )}
      </div>
    </nav>
  )
}
