// ACTION TYPES
export const LOGIN_REQUEST = 'LOGIN_REQUEST'
export const LOGIN_SUCCESS = 'LOGIN_SUCCESS'
export const LOGIN_FAILURE = 'LOGIN_FAILURE'
export const LOGOUT = 'LOGOUT'

export const ADD_TASK = 'ADD_TASK'
export const DELETE_TASK = 'DELETE_TASK'

// THUNKS
export const login = (username, password, onSuccess) => {
  return async (dispatch) => {
    dispatch({ type: LOGIN_REQUEST })
    // simulate async login
    await new Promise(r => setTimeout(r, 700))
    // simple demo logic
    if (password === 'admin') {
      const user = { username }
      localStorage.setItem('auth', JSON.stringify({ isAuthenticated: true, user }))
      dispatch({ type: LOGIN_SUCCESS, payload: user })
      if (onSuccess) onSuccess()
    } else {
      dispatch({ type: LOGIN_FAILURE, error: 'Invalid credentials (hint: password is "admin")' })
    }
  }
}

export const logout = () => {
  localStorage.removeItem('auth')
  return { type: LOGOUT }
}

export const addTask = (title) => ({
  type: ADD_TASK,
  payload: { id: Date.now(), title }
})

export const deleteTask = (id) => ({
  type: DELETE_TASK,
  payload: id
})
