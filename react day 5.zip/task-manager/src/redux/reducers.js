import { combineReducers } from 'redux'
import {
  LOGIN_REQUEST, LOGIN_SUCCESS, LOGIN_FAILURE, LOGOUT,
  ADD_TASK, DELETE_TASK
} from './actions'

const savedAuth = (() => {
  try {
    return JSON.parse(localStorage.getItem('auth')) || { isAuthenticated: false, user: null }
  } catch { return { isAuthenticated: false, user: null } }
})()

const initialAuth = {
  isAuthenticated: savedAuth.isAuthenticated,
  user: savedAuth.user,
  loading: false,
  error: null
}

function auth(state = initialAuth, action) {
  switch (action.type) {
    case LOGIN_REQUEST:
      return { ...state, loading: true, error: null }
    case LOGIN_SUCCESS:
      return { ...state, loading: false, isAuthenticated: true, user: action.payload }
    case LOGIN_FAILURE:
      return { ...state, loading: false, error: action.error, isAuthenticated: false, user: null }
    case LOGOUT:
      return { ...state, isAuthenticated: false, user: null }
    default:
      return state
  }
}

const initialTasks = {
  items: [
    { id: 1, title: 'Explore the app' },
    { id: 2, title: 'Add and delete tasks' }
  ]
}

function tasks(state = initialTasks, action) {
  switch (action.type) {
    case ADD_TASK:
      return { ...state, items: [action.payload, ...state.items] }
    case DELETE_TASK:
      return { ...state, items: state.items.filter(t => t.id !== action.payload) }
    default:
      return state
  }
}

export default combineReducers({ auth, tasks })
